package com.cit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProject6Application {

	public static void main(String[] args) {
		SpringApplication.run(FinalProject6Application.class, args);
	}
}
